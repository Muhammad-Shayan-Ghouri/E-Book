<?php

// ---- Redirect helper ----
function redirect($url) {
    header("Location: " . BASE_URL . $url);
    exit;
}

// ---- Flash messages (1-time notifications) ----
function set_flash($msg, $type = 'info') {
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
}

function get_flash() {
    if (isset($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

// ---- User auth helpers ----
function current_user() {
    return $_SESSION['user'] ?? null;
}

function require_login() {
    if (!current_user()) {
        set_flash("Please login first", "error");
        redirect("/public/login.php");
    }
}

function require_admin() {
    if (!current_user() || current_user()['is_admin'] != 1) {
        set_flash("Unauthorized", "error");
        redirect("/public/login.php");
    }
}

// ---- Login function ----
function attempt_login($email, $password, $pdo) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['user'] = $user;
        return true;
    }
    return false;
}

// ---- Logout ----
function do_logout() {
    unset($_SESSION['user']);
}
