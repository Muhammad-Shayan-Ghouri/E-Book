<?php
require_once __DIR__ . '/../init.php';
require_admin();

// count totals
$totalBooks = $pdo->query("SELECT COUNT(*) FROM books")->fetchColumn();
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users WHERE is_admin = 0")->fetchColumn();
$totalOrders = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$totalComps = $pdo->query("SELECT COUNT(*) FROM competitions")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../public/assets/css/style.css">
</head>
<body>
    <h1>Admin Dashboard</h1>
    <nav>
        <a href="index.php">Dashboard</a>
        <a href="books.php">Books</a>
        <a href="competitions.php">Competitions</a>
        <a href="submissions.php">Submissions</a>
        <a href="winners.php">Winners</a>
        <a href="logout.php">Logout</a>
    </nav>

    <?php if ($flash = get_flash()): ?>
        <div class="flash <?= htmlspecialchars($flash['type']) ?>">
            <?= htmlspecialchars($flash['msg']) ?>
        </div>
    <?php endif; ?>

    <section>
        <h2>Stats</h2>
        <ul>
            <li>Total Books: <?= $totalBooks ?></li>
            <li>Total Users: <?= $totalUsers ?></li>
            <li>Total Orders: <?= $totalOrders ?></li>
            <li>Total Competitions: <?= $totalComps ?></li>
        </ul>
    </section>

    <script src="assets/js/app.js"></script>

</body>
</html>
