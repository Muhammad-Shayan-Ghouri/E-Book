<?php
require_once __DIR__ . '/../init.php';
require_admin();

$id = (int)($_GET['id'] ?? 0);
$comp = null;

if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM competitions WHERE id = ?");
    $stmt->execute([$id]);
    $comp = $stmt->fetch();
    if (!$comp) {
        set_flash("Competition not found", "error");
        redirect("/admin/competitions.php");
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $prize = trim($_POST['prize'] ?? '');
    $start = $_POST['start_datetime'] ?? '';
    $end   = $_POST['end_datetime'] ?? '';

    if ($id) {
        $pdo->prepare("UPDATE competitions SET name=?,description=?,prize=?,start_datetime=?,end_datetime=? WHERE id=?")
            ->execute([$name,$desc,$prize,$start,$end,$id]);
        set_flash("Competition updated", "success");
    } else {
        $pdo->prepare("INSERT INTO competitions (name,description,prize,start_datetime,end_datetime) VALUES (?,?,?,?,?)")
            ->execute([$name,$desc,$prize,$start,$end]);
        set_flash("Competition created", "success");
    }

    redirect("/admin/competitions.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $id ? "Edit Competition" : "Add Competition" ?></title>
    <link rel="stylesheet" href="../public/assets/css/style.css">
</head>
<body>
    <h1><?= $id ? "Edit Competition" : "Add Competition" ?></h1>
    <nav>
        <a href="competitions.php">← Back to Competitions</a>
    </nav>

    <form method="post">
        <label>Name:<br>
            <input type="text" name="name" value="<?= htmlspecialchars($comp['name'] ?? '') ?>" required>
        </label><br>
        <label>Description:<br>
            <textarea name="description" required><?= htmlspecialchars($comp['description'] ?? '') ?></textarea>
        </label><br>
        <label>Prize:<br>
            <input type="text" name="prize" value="<?= htmlspecialchars($comp['prize'] ?? '') ?>">
        </label><br>
        <label>Start Date & Time:<br>
            <input type="datetime-local" name="start_datetime" value="<?= $comp ? date('Y-m-d\TH:i', strtotime($comp['start_datetime'])) : '' ?>" required>
        </label><br>
        <label>End Date & Time:<br>
            <input type="datetime-local" name="end_datetime" value="<?= $comp ? date('Y-m-d\TH:i', strtotime($comp['end_datetime'])) : '' ?>" required>
        </label><br>
        <button type="submit"><?= $id ? "Update" : "Create" ?> Competition</button>
    </form>

<script src="assets/js/app.js"></script>

</body>
</html>
