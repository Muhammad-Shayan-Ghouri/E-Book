<?php
require_once __DIR__ . '/../init.php';
require_admin();

// mark winner
if (isset($_GET['win'])) {
    $id = (int)$_GET['win'];
    $pdo->prepare("UPDATE submissions SET is_winner = 1 WHERE id = ?")->execute([$id]);
    set_flash("Winner selected!", "success");
    redirect("/admin/winners.php");
}

// fetch winners + top scored submissions
$sql = "SELECT s.*, u.name as user_name, c.name as comp_name
        FROM submissions s
        JOIN users u ON s.user_id = u.id
        JOIN competitions c ON s.competition_id = c.id
        ORDER BY s.is_winner DESC, s.score DESC";
$subs = $pdo->query($sql)->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Competition Winners</title>
    <link rel="stylesheet" href="../public/assets/css/style.css">
</head>
<body>
    <h1>Competition Winners</h1>
    <nav>
        <a href="index.php">Dashboard</a>
        <a href="books.php">Books</a>
        <a href="competitions.php">Competitions</a>
        <a href="submissions.php">Submissions</a>
        <a href="winners.php">Winners</a>
        <a href="logout.php">Logout</a>
    </nav>

    <?php if ($flash = get_flash()): ?>
        <div class="flash <?= htmlspecialchars($flash['type']) ?>">
            <?= htmlspecialchars($flash['msg']) ?>
        </div>
    <?php endif; ?>

    <table>
        <tr>
            <th>ID</th>
            <th>User</th>
            <th>Competition</th>
            <th>Score</th>
            <th>Winner</th>
            <th>Action</th>
        </tr>
        <?php foreach ($subs as $s): ?>
        <tr>
            <td><?= $s['id'] ?></td>
            <td><?= htmlspecialchars($s['user_name']) ?></td>
            <td><?= htmlspecialchars($s['comp_name']) ?></td>
            <td><?= $s['score'] !== null ? $s['score'] : '-' ?></td>
            <td><?= $s['is_winner'] ? "🏆 Yes" : "No" ?></td>
            <td>
                <?php if (!$s['is_winner']): ?>
                    <a href="winners.php?win=<?= $s['id'] ?>" onclick="return confirm('Mark as winner?')">Mark Winner</a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <script src="assets/js/app.js"></script>
    
</body>
</html>
