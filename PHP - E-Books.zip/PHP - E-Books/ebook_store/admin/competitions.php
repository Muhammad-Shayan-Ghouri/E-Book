<?php
require_once __DIR__ . '/../init.php';
require_admin();

// saare competitions fetch karo
$comps = $pdo->query("SELECT * FROM competitions ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Competitions</title>
    <link rel="stylesheet" href="../public/assets/css/style.css">
</head>
<body>
    <h1>Manage Competitions</h1>
    <nav>
        <a href="index.php">Dashboard</a>
        <a href="books.php">Books</a>
        <a href="competitions.php">Competitions</a>
        <a href="submissions.php">Submissions</a>
        <a href="winners.php">Winners</a>
        <a href="logout.php">Logout</a>
    </nav>

    <?php if ($flash = get_flash()): ?>
        <div class="flash <?= htmlspecialchars($flash['type']) ?>">
            <?= htmlspecialchars($flash['msg']) ?>
        </div>
    <?php endif; ?>

    <p><a href="competition_form.php">+ Add Competition</a></p>

    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Prize</th>
            <th>Start</th>
            <th>End</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($comps as $c): ?>
        <tr>
            <td><?= $c['id'] ?></td>
            <td><?= htmlspecialchars($c['name']) ?></td>
            <td><?= htmlspecialchars($c['prize']) ?></td>
            <td><?= $c['start_datetime'] ?></td>
            <td><?= $c['end_datetime'] ?></td>
            <td>
                <a href="competition_form.php?id=<?= $c['id'] ?>">Edit</a> |
                <a href="competition_delete.php?id=<?= $c['id'] ?>" onclick="return confirm('Delete this competition?')">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <script src="assets/js/app.js"></script>
    
</body>
</html>
