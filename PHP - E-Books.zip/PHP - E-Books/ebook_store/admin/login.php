<?php
require_once __DIR__ . '/../init.php';

// Agar already login hai aur admin hai → dashboard bhej do
if (current_user() && current_user()['is_admin']) {
    redirect("/admin/index.php");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';

    if (attempt_login($email, $pass, $pdo) && current_user()['is_admin']) {
        set_flash("Welcome Admin!", "success");
        redirect("/admin/index.php");
    } else {
        set_flash("Invalid admin credentials.", "error");
        do_logout(); // ensure koi user session bacha na ho
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>
    <link rel="stylesheet" href="../public/assets/css/style.css">
</head>
<body>
    <h1>Admin Login</h1>
    <?php if ($flash = get_flash()): ?>
        <div class="flash <?= htmlspecialchars($flash['type']) ?>">
            <?= htmlspecialchars($flash['msg']) ?>
        </div>
    <?php endif; ?>

    <form method="post">
        <label>Email:<br>
            <input type="email" name="email" required>
        </label><br>
        <label>Password:<br>
            <input type="password" name="password" required>
        </label><br>
        <button type="submit">Login</button>
    </form>
    
    <script src="assets/js/app.js"></script>

</body>
</html>
