<?php
require_once __DIR__ . '/../init.php';
require_admin();

$id = (int)($_GET['id'] ?? 0);
$book = null;

if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM books WHERE id = ?");
    $stmt->execute([$id]);
    $book = $stmt->fetch();
    if (!$book) {
        set_flash("Book not found", "error");
        redirect("/admin/books.php");
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $author = trim($_POST['author'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $price = (float)($_POST['price'] ?? 0);
    $format = $_POST['format'] ?? 'pdf';
    $stock = (int)($_POST['stock'] ?? 0);

    $filePath = $book['file_path'] ?? null;

    if ($format === 'pdf' && isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        $dir = UPLOAD_DIR . "/books";
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
        if ($ext === 'pdf') {
            $newName = "book_" . time() . ".pdf";
            $path = $dir . "/" . $newName;
            if (move_uploaded_file($_FILES['file']['tmp_name'], $path)) {
                $filePath = "uploads/books/" . $newName;
            }
        }
    }

    if ($id) {
        $pdo->prepare("UPDATE books SET title=?,author=?,description=?,price=?,format=?,stock=?,file_path=? WHERE id=?")
            ->execute([$title,$author,$desc,$price,$format,$stock,$filePath,$id]);
        set_flash("Book updated", "success");
    } else {
        $pdo->prepare("INSERT INTO books (title,author,description,price,format,stock,file_path) VALUES (?,?,?,?,?,?,?)")
            ->execute([$title,$author,$desc,$price,$format,$stock,$filePath]);
        set_flash("Book added", "success");
    }

    redirect("/admin/books.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $id ? "Edit Book" : "Add Book" ?></title>
    <link rel="stylesheet" href="../public/assets/css/style.css">
</head>
<body>
    <h1><?= $id ? "Edit Book" : "Add Book" ?></h1>
    <nav>
        <a href="books.php">← Back to Books</a>
    </nav>

    <form method="post" enctype="multipart/form-data">
        <label>Title:<br>
            <input type="text" name="title" value="<?= htmlspecialchars($book['title'] ?? '') ?>" required>
        </label><br>
        <label>Author:<br>
            <input type="text" name="author" value="<?= htmlspecialchars($book['author'] ?? '') ?>" required>
        </label><br>
        <label>Description:<br>
            <textarea name="description" required><?= htmlspecialchars($book['description'] ?? '') ?></textarea>
        </label><br>
        <label>Price:<br>
            <input type="number" step="0.01" name="price" value="<?= htmlspecialchars($book['price'] ?? 0) ?>" required>
        </label><br>
        <label>Format:<br>
            <select name="format">
                <option value="pdf" <?= ($book['format'] ?? '')==='pdf'?'selected':'' ?>>PDF</option>
                <option value="cd" <?= ($book['format'] ?? '')==='cd'?'selected':'' ?>>CD</option>
                <option value="hard" <?= ($book['format'] ?? '')==='hard'?'selected':'' ?>>Hard Copy</option>
            </select>
        </label><br>
        <label>Stock:<br>
            <input type="number" name="stock" value="<?= htmlspecialchars($book['stock'] ?? 0) ?>">
        </label><br>
        <label>PDF File (only if format=PDF):<br>
            <input type="file" name="file">
        </label><br>
        <button type="submit"><?= $id ? "Update" : "Add" ?> Book</button>
    </form>
    
    <script src="assets/js/app.js"></script>
</body>
</html>
