<?php
require_once __DIR__ . '/../init.php';
require_admin();

// books load
$books = $pdo->query("SELECT * FROM books ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Books</title>
    <link rel="stylesheet" href="../public/assets/css/style.css">
</head>
<body>
    <h1>Manage Books</h1>
    <nav>
        <a href="index.php">Dashboard</a>
        <a href="books.php">Books</a>
        <a href="competitions.php">Competitions</a>
        <a href="submissions.php">Submissions</a>
        <a href="winners.php">Winners</a>
        <a href="logout.php">Logout</a>
    </nav>

    <?php if ($flash = get_flash()): ?>
        <div class="flash <?= htmlspecialchars($flash['type']) ?>">
            <?= htmlspecialchars($flash['msg']) ?>
        </div>
    <?php endif; ?>

    <p><a href="book_form.php">+ Add New Book</a></p>

    <table>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>Format</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($books as $b): ?>
        <tr>
            <td><?= $b['id'] ?></td>
            <td><?= htmlspecialchars($b['title']) ?></td>
            <td><?= htmlspecialchars($b['author']) ?></td>
            <td><?= $b['format'] ?></td>
            <td><?= $b['price'] ?></td>
            <td><?= $b['stock'] ?></td>
            <td>
                <a href="book_form.php?id=<?= $b['id'] ?>">Edit</a> |
                <a href="book_delete.php?id=<?= $b['id'] ?>" onclick="return confirm('Delete this book?')">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
    <script src="assets/js/app.js"></script>
</body>
</html>
