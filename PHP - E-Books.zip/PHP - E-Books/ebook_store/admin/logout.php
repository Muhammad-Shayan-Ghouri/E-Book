<?php
require_once __DIR__ . '/../init.php';

do_logout();
set_flash("Admin logged out.", "info");
redirect("/admin/login.php");
