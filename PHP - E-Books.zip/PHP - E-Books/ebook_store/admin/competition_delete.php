<?php
require_once __DIR__ . '/../init.php';
require_admin();

$id = (int)($_GET['id'] ?? 0);

if ($id) {
    $stmt = $pdo->prepare("DELETE FROM competitions WHERE id = ?");
    $stmt->execute([$id]);
    set_flash("Competition deleted", "success");
}

redirect("/admin/competitions.php");
