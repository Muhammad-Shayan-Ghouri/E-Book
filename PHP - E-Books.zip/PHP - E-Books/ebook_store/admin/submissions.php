<?php
require_once __DIR__ . '/../init.php';
require_admin();

// score update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'], $_POST['score'])) {
    $id = (int)$_POST['id'];
    $score = (int)$_POST['score'];
    $pdo->prepare("UPDATE submissions SET score=? WHERE id=?")->execute([$score, $id]);
    set_flash("Score updated", "success");
    redirect("/admin/submissions.php");
}

// fetch all submissions
$sql = "SELECT s.*, u.name as user_name, c.name as comp_name
        FROM submissions s
        JOIN users u ON s.user_id = u.id
        JOIN competitions c ON s.competition_id = c.id
        ORDER BY s.submitted_at DESC";
$subs = $pdo->query($sql)->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Competition Submissions</title>
    <link rel="stylesheet" href="../public/assets/css/style.css">
</head>
<body>
    <h1>Competition Submissions</h1>
    <nav>
        <a href="index.php">Dashboard</a>
        <a href="books.php">Books</a>
        <a href="competitions.php">Competitions</a>
        <a href="submissions.php">Submissions</a>
        <a href="winners.php">Winners</a>
        <a href="logout.php">Logout</a>
    </nav>

    <?php if ($flash = get_flash()): ?>
        <div class="flash <?= htmlspecialchars($flash['type']) ?>">
            <?= htmlspecialchars($flash['msg']) ?>
        </div>
    <?php endif; ?>

    <table>
        <tr>
            <th>ID</th>
            <th>User</th>
            <th>Competition</th>
            <th>File</th>
            <th>Submitted</th>
            <th>Score</th>
            <th>Update</th>
        </tr>
        <?php foreach ($subs as $s): ?>
        <tr>
            <td><?= $s['id'] ?></td>
            <td><?= htmlspecialchars($s['user_name']) ?></td>
            <td><?= htmlspecialchars($s['comp_name']) ?></td>
            <td><a href="../<?= htmlspecialchars($s['file_path']) ?>" target="_blank">View</a></td>
            <td><?= $s['submitted_at'] ?></td>
            <td><?= $s['score'] !== null ? $s['score'] : '-' ?></td>
            <td>
                <form method="post" style="display:inline;">
                    <input type="hidden" name="id" value="<?= $s['id'] ?>">
                    <input type="number" name="score" value="<?= $s['score'] ?>" min="0" max="100">
                    <button type="submit">Save</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

<script src="assets/js/app.js"></script>

</body>
</html>
