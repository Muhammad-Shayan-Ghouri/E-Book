<?php
// ====== DATABASE SETTINGS (MySQL) ======
const DB_HOST = '127.0.0.1';
const DB_NAME = 'ebook_store';   // phpMyAdmin me yehi naam ka DB banao
const DB_USER = 'root';
const DB_PASS = '';              // XAMPP default blank hota hai

// ====== ADMIN BOOTSTRAP ======
// Pehli dafa site khulti hi agar ye admin na mila to auto-create ho jayega.
// In donon ko apni marzi se change kar lo.
const ADMIN_EMAIL = 'admin@gmail.com';
const ADMIN_PASSWORD = 'admin7';

// ====== PATHS / URLS ======
const BASE_URL = '/ebook_store';       // folder ka naam. agar kuch aur rakha hai to yahan update karo.
const UPLOAD_DIR = __DIR__ . '/uploads';   // PDFs, submissions yahan jayengi

// ====== APP SETTINGS ======
date_default_timezone_set('Asia/Karachi');

// Theme colors (frontend CSS me use kar lenge)
const THEME_PRIMARY = '#2ecc71'; // light green
const THEME_DARK    = '#0e1a16'; // dark tone

// Security: simple token salt (basic CSRF/tokens me kaam ayega)
const APP_TOKEN_SALT = 'change_this_to_any_random_long_string_2025';
