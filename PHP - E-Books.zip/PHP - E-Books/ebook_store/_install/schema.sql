-- Agar pehle se tables hain to unko delete karo
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS submissions;
DROP TABLE IF EXISTS competitions;
DROP TABLE IF EXISTS books;
DROP TABLE IF EXISTS users;

-- Users (admin + customers)
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  is_admin TINYINT(1) DEFAULT 0,
  membership_until DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Books
CREATE TABLE books (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  author VARCHAR(120) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL DEFAULT 0,
  format ENUM('pdf','cd','hard') NOT NULL,
  stock INT DEFAULT 0,
  file_path VARCHAR(255) NULL,
  is_active TINYINT(1) DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Orders
CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  payment_method ENUM('cod','card','paypal') NOT NULL,
  status ENUM('pending','paid','shipped') DEFAULT 'pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Order items
CREATE TABLE order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  book_id INT NOT NULL,
  qty INT NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id),
  FOREIGN KEY (book_id) REFERENCES books(id)
);

-- Competitions
CREATE TABLE competitions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  description TEXT,
  prize VARCHAR(200),
  start_datetime DATETIME NOT NULL,
  end_datetime DATETIME NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Submissions (essay uploads)
CREATE TABLE submissions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  competition_id INT NOT NULL,
  user_id INT NOT NULL,
  file_path VARCHAR(255) NOT NULL,
  submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  score INT NULL,
  is_winner TINYINT(1) NULL,
  FOREIGN KEY (competition_id) REFERENCES competitions(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Demo books
INSERT INTO books (title, author, description, price, format, stock, file_path) VALUES
('Learn HTML Fast', 'A. Coder', 'Beginner friendly HTML notes.', 0.00, 'pdf', 0, 'uploads/books/learn-html.pdf'),
('Green Garden Tales', 'S. Writer', 'Short stories for all ages.', 799.00, 'hard', 50, NULL),
('JavaScript Basics (CD)', 'K. Dev', 'Starter JS course as files on CD.', 999.00, 'cd', 20, NULL),
('Laravel Cheats (PDF)', 'N. Ninja', 'Quick Laravel tips.', 299.00, 'pdf', 0, 'uploads/books/laravel-cheats.pdf');

-- Demo competition
INSERT INTO competitions (name, description, prize, start_datetime, end_datetime) VALUES
('Story Writing September', 'Write a short story (500-1500 words).', 'Rs 5,000 + feature', DATE_ADD(NOW(), INTERVAL 1 DAY), DATE_ADD(NOW(), INTERVAL 4 DAY));
