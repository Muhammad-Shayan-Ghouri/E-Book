-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 11, 2025 at 06:22 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

CREATE DATABASE IF NOT EXISTS ebook_store;
USE ebook_store;


SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ebook_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `author` varchar(120) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `format` enum('pdf','cd','hard') NOT NULL,
  `stock` int(11) DEFAULT 0,
  `file_path` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `description`, `price`, `format`, `stock`, `file_path`, `is_active`, `created_at`) VALUES
(5, 'Spider-Man: Into the Multiverse', 'Marvel Comics', 'Peter Parker faces a thrilling adventure across parallel worlds, meeting different versions of Spider-Man in an action-packed multiverse story.', 299.00, 'pdf', 35, NULL, 1, '2025-09-08 19:07:27'),
(6, 'Batman: The Dark Knight Returns', 'DC Comics', 'Bruce Wayne comes out of retirement to protect Gotham once again. A dark, gritty tale showing the true essence of the Dark Knight.', 349.00, 'cd', 20, NULL, 1, '2025-09-08 19:08:22'),
(7, 'Superman: Man of Tomorrow', 'DC Comics', 'Clark Kent embraces his powers to save humanity while protecting his secret identity. A story of hope, strength, and courage.', 279.00, 'hard', 153, NULL, 1, '2025-09-08 19:09:25'),
(8, 'The Avengers: Earth’s Mightiest Heroes', 'Marvel Comics', 'Earth’s strongest heroes unite — Iron Man, Thor, Hulk, and Captain America — to fight off a massive alien invasion.', 399.00, 'cd', 55, NULL, 1, '2025-09-08 19:10:08'),
(9, 'Wonder Woman: Warrior’s Spirit', 'DC Comics', 'Diana Prince stands as a fearless Amazon warrior, fighting for justice and truth in a modern world.', 320.00, 'pdf', 33, NULL, 1, '2025-09-08 19:10:59'),
(10, 'Iron Man: Armor Up', 'Marvel Comics', 'Tony Stark builds new advanced armors to face powerful enemies. A mix of cutting-edge technology and superhero action.', 310.00, 'hard', 199, NULL, 1, '2025-09-08 19:11:59'),
(11, 'The Flash: Speed Force', 'DC Comics', 'Barry Allen uses his incredible speed to fight crime and explore the mysteries of the multiverse. Fast-paced and full of excitement.', 299.00, 'pdf', 222, NULL, 1, '2025-09-08 19:12:41'),
(12, 'Thor: God of Thunder', 'Marvel Comics', 'Wielding the mighty hammer Mjölnir, Thor battles gods and monsters to protect Asgard and Earth. A tale of mythology and power.', 340.00, 'cd', 63, NULL, 1, '2025-09-08 19:13:27'),
(13, 'Hulk: Smash!', 'Marvel Comics', 'When Bruce Banner transforms into the Hulk, nothing can stand in his way. Explosive battles filled with raw power and emotion.', 280.00, 'cd', 236, NULL, 1, '2025-09-08 19:14:06'),
(14, 'Justice League: United We Stand', 'DC Comics', 'DC’s greatest heroes — Superman, Batman, Wonder Woman, and more — join forces to save the world from ultimate destruction.', 450.00, 'pdf', 89, NULL, 1, '2025-09-08 19:14:48');

-- --------------------------------------------------------

--
-- Table structure for table `competitions`
--

CREATE TABLE `competitions` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `prize` varchar(200) DEFAULT NULL,
  `start_datetime` datetime NOT NULL,
  `end_datetime` datetime NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `competitions`
--

INSERT INTO `competitions` (`id`, `name`, `description`, `prize`, `start_datetime`, `end_datetime`, `created_at`) VALUES
(1, 'Story Writing September', 'Write a short story (500-1500 words).', 'Rs 5,000 + feature', '2025-09-06 16:19:10', '2025-09-09 16:19:10', '2025-09-05 16:19:10');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `payment_method` enum('cod','card','paypal') NOT NULL,
  `status` enum('pending','paid','shipped') DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `total`, `payment_method`, `status`, `created_at`) VALUES
(1, 1, 299.00, 'card', 'paid', '2025-09-05 16:20:20'),
(2, 2, 799.00, 'cod', 'pending', '2025-09-05 16:20:20'),
(3, 3, 999.00, 'paypal', 'paid', '2025-09-05 16:20:20'),
(4, 5, 340.00, 'cod', 'pending', '2025-09-09 17:06:15'),
(5, 5, 450.00, 'card', 'paid', '2025-09-09 17:06:29');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `book_id`, `qty`, `unit_price`) VALUES
(4, 4, 12, 1, 340.00),
(5, 5, 14, 1, 450.00);

-- --------------------------------------------------------

--
-- Table structure for table `submissions`
--

CREATE TABLE `submissions` (
  `id` int(11) NOT NULL,
  `competition_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `submitted_at` datetime DEFAULT current_timestamp(),
  `score` int(11) DEFAULT NULL,
  `is_winner` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `submissions`
--

INSERT INTO `submissions` (`id`, `competition_id`, `user_id`, `file_path`, `submitted_at`, `score`, `is_winner`) VALUES
(1, 1, 1, 'uploads/essays/demo_ali.txt', '2025-09-05 16:20:27', 85, NULL),
(2, 1, 2, 'uploads/essays/demo_sara.txt', '2025-09-05 16:20:27', 90, 1),
(3, 1, 3, 'uploads/essays/demo_bilal.txt', '2025-09-05 16:20:27', 75, NULL),
(4, 1, 4, 'uploads/essays/essay_4_1757071843.txt', '2025-09-05 16:30:43', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(120) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `is_admin` tinyint(1) DEFAULT 0,
  `membership_until` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password_hash`, `is_admin`, `membership_until`, `created_at`) VALUES
(1, 'Ali Khan', 'ali@example.com', '*8B18C4DA3DE9DE05BCB3A7C13BE10DDA14DA258A', 0, '2025-12-05 16:20:34', '2025-09-05 16:20:04'),
(2, 'Sara Ahmed', 'sara@example.com', '*1D35E37484D26EA363FC06D763095AEF8094DF09', 0, NULL, '2025-09-05 16:20:04'),
(3, 'Bilal Sheikh', 'bilal@example.com', '*7E0D44C4C8C53AEFCA129865F1E2D3632D6DC2A5', 0, NULL, '2025-09-05 16:20:04'),
(4, 'Admin', 'admin@gmail.com', '$2y$10$Ae9mR9bIMTlo5fmaGZCpNuFstpYrjzJA4s1L0A517P1D695dAvdba', 1, NULL, '2025-09-05 16:21:34'),
(5, 'Raess', 'user@gmail.com', '$2y$10$bf7030rtsTFPIvU8MJXRqedB1WxeGe22m.DxIvUiEfJxU1LhOAApK', 0, NULL, '2025-09-09 17:05:34');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `competitions`
--
ALTER TABLE `competitions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `fk_orderitems_book` (`book_id`);

--
-- Indexes for table `submissions`
--
ALTER TABLE `submissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `competition_id` (`competition_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `competitions`
--
ALTER TABLE `competitions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `submissions`
--
ALTER TABLE `submissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `fk_orderitems_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`);

--
-- Constraints for table `submissions`
--
ALTER TABLE `submissions`
  ADD CONSTRAINT `submissions_ibfk_1` FOREIGN KEY (`competition_id`) REFERENCES `competitions` (`id`),
  ADD CONSTRAINT `submissions_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
