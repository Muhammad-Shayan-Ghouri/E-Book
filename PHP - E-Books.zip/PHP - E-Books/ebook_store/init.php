<?php
// session start
session_start();

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';

// ===== AUTO ADMIN CREATE =====
try {
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
    $stmt->execute([ADMIN_EMAIL]);
    $admin = $stmt->fetch();

    if (!$admin) {
        // agar admin nahi mila to naya create kar do
        $hash = password_hash(ADMIN_PASSWORD, PASSWORD_DEFAULT);
        $pdo->prepare("INSERT INTO users (name, email, password_hash, is_admin) VALUES (?, ?, ?, 1)")
            ->execute(['Admin', ADMIN_EMAIL, $hash]);
    }
} catch (Exception $e) {
    // ignore agar abhi DB tables create nahi hue
}
