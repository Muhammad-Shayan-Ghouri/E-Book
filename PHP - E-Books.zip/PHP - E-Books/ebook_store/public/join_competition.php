<?php
require_once __DIR__ . '/../init.php';
require_login();

$id = (int)($_GET['id'] ?? 0);

// Competition check
$stmt = $pdo->prepare("SELECT * FROM competitions WHERE id = ?");
$stmt->execute([$id]);
$comp = $stmt->fetch();

if (!$comp) {
    set_flash("Competition not found.", "error");
    redirect("/public/competition.php");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['essay'])) {
    $file = $_FILES['essay'];

    if ($file['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['pdf','doc','docx','txt'])) {
            set_flash("Only PDF/DOC/TXT allowed.", "error");
        } else {
            $dir = UPLOAD_DIR . "/essays";
            if (!is_dir($dir)) {
                mkdir($dir, 0777, true);
            }

            $newName = "essay_" . current_user()['id'] . "_" . time() . "." . $ext;
            $path = $dir . "/" . $newName;

            if (move_uploaded_file($file['tmp_name'], $path)) {
                $relPath = "uploads/essays/" . $newName;

                $pdo->prepare("INSERT INTO submissions (competition_id,user_id,file_path) VALUES (?,?,?)")
                    ->execute([$comp['id'], current_user()['id'], $relPath]);

                set_flash("Your entry has been submitted!", "success");
                redirect("/public/competition.php?id=" . $comp['id']);
            } else {
                set_flash("Upload failed.", "error");
            }
        }
    } else {
        set_flash("File error.", "error");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Join Competition</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f6f9;
            color: #333;
        }

        h1 {
            text-align: center;
            background: #2c3e50;
            color: #fff;
            padding: 20px 0;
            margin: 0;
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-top: 25px;
        }

        .flash {
            max-width: 600px;
            margin: 20px auto;
            padding: 15px;
            border-radius: 6px;
            text-align: center;
            font-weight: bold;
        }

        .flash.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .flash.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        form {
            max-width: 500px;
            margin: 30px auto;
            padding: 25px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 12px;
            color: #2c3e50;
        }

        input[type="file"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccd1d9;
            border-radius: 6px;
            margin-top: 8px;
            cursor: pointer;
        }

        button {
            display: inline-block;
            margin-top: 20px;
            padding: 12px 20px;
            background: #1abc9c;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s;
        }

        button:hover {
            background: #16a085;
        }
    </style>
</head>
<body>
    <h1>Join Competition</h1>
    <h2><?= htmlspecialchars($comp['name']) ?></h2>

    <?php if ($flash = get_flash()): ?>
        <div class="flash <?= htmlspecialchars($flash['type']) ?>">
            <?= htmlspecialchars($flash['msg']) ?>
        </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
        <label>Upload your essay (PDF/DOC/TXT):
            <input type="file" name="essay" required>
        </label>
        <button type="submit">Submit Entry</button>
    </form>

    <script src="assets/js/app.js"></script>
</body>
</html>


