<?php
require_once __DIR__ . '/../init.php';

// Single competition view
if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM competitions WHERE id = ?");
    $stmt->execute([$id]);
    $comp = $stmt->fetch();

    if (!$comp) {
        set_flash("Competition not found.", "error");
        redirect("/public/competition.php");
    }
} else {
    // list all active competitions
    $now = date('Y-m-d H:i:s');
    $stmt = $pdo->prepare("SELECT * FROM competitions WHERE end_datetime >= ? ORDER BY start_datetime ASC");
    $stmt->execute([$now]);
    $competitions = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Competitions</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f5f7fa;
            color: #333;
        }

        h1 {
            text-align: center;
            background: #2c3e50;
            color: #fff;
            padding: 20px 0;
            margin: 0;
        }

        nav {
            background: #34495e;
            display: flex;
            justify-content: center;
            gap: 20px;
            padding: 12px 0;
        }

        nav a {
            color: #ecf0f1;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s;
        }

        nav a:hover {
            color: #1abc9c;
        }

        main {
            max-width: 900px;
            margin: 30px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        h2 {
            color: #2c3e50;
            margin-top: 0;
        }

        p {
            line-height: 1.6;
        }

        a.btn {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 15px;
            background: #1abc9c;
            color: white;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            transition: background 0.3s;
        }

        a.btn:hover {
            background: #16a085;
        }

        ul {
            list-style: none;
            padding: 0;
        }

        li {
            margin: 12px 0;
            padding: 12px;
            background: #f8f9fa;
            border-radius: 6px;
            transition: transform 0.2s;
        }

        li:hover {
            transform: translateX(5px);
            background: #eef2f3;
        }
    </style>
</head>
<body>
    <h1>Competitions</h1>
    <nav>
        <a href="index.php">Home</a>
        <a href="cart.php">Cart</a>
        <a href="competition.php">Competitions</a>
        <a href="downloads.php">My Downloads</a>
    </nav>

    <main>
    <?php if (isset($comp)): ?>
        <h2><?= htmlspecialchars($comp['name']) ?></h2>
        <p><?= nl2br(htmlspecialchars($comp['description'])) ?></p>
        <p><strong>Prize:</strong> <?= htmlspecialchars($comp['prize']) ?></p>
        <p><strong>From:</strong> <?= date('d M Y H:i', strtotime($comp['start_datetime'])) ?>
           - <strong>To:</strong> <?= date('d M Y H:i', strtotime($comp['end_datetime'])) ?></p>

        <?php if (current_user()): ?>
            <a class="btn" href="join_competition.php?id=<?= $comp['id'] ?>">Join / Submit Entry</a>
        <?php else: ?>
            <p><a class="btn" href="login.php">Login</a> to participate.</p>
        <?php endif; ?>

    <?php else: ?>
        <h2>Active Competitions</h2>
        <?php if ($competitions): ?>
            <ul>
            <?php foreach ($competitions as $c): ?>
                <li>
                    <a href="competition.php?id=<?= $c['id'] ?>">
                        <?= htmlspecialchars($c['name']) ?>
                    </a>
                    <span style="color:#7f8c8d;"> (till <?= date('d M Y', strtotime($c['end_datetime'])) ?>)</span>
                </li>
            <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>No active competitions right now.</p>
        <?php endif; ?>
    <?php endif; ?>
    </main>

    <script src="assets/js/app.js"></script>
</body>
</html>
