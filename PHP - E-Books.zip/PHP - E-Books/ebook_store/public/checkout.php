<?php
require_once __DIR__ . '/../init.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cart = $_SESSION['cart'] ?? [];
    if (!$cart) {
        set_flash("Your cart is empty.", "error");
        redirect("/public/cart.php");
    }

    $payment = $_POST['payment_method'] ?? 'cod';
    if (!in_array($payment, ['cod','card','paypal'])) {
        $payment = 'cod';
    }

    // collect books
    $ids = implode(",", array_map("intval", array_keys($cart)));
    $stmt = $pdo->query("SELECT * FROM books WHERE id IN ($ids)");
    $books = $stmt->fetchAll();

    $total = 0;
    foreach ($books as $b) {
        $total += $b['price'] * $cart[$b['id']];
    }

    // insert order
    $pdo->prepare("INSERT INTO orders (user_id,total,payment_method,status) VALUES (?,?,?,?)")
        ->execute([current_user()['id'], $total, $payment, $payment === 'cod' ? 'pending' : 'paid']);
    $orderId = $pdo->lastInsertId();

    // insert order items
    $oi = $pdo->prepare("INSERT INTO order_items (order_id, book_id, qty, unit_price) VALUES (?,?,?,?)");
    foreach ($books as $b) {
        $oi->execute([$orderId, $b['id'], $cart[$b['id']], $b['price']]);
    }

    // empty cart
    unset($_SESSION['cart']);

    set_flash("Order placed successfully! Your payment method: $payment", "success");
    redirect("/public/index.php");
} else {
    redirect("/public/cart.php");
}
