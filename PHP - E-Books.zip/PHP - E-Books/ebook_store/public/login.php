<?php
require_once __DIR__ . '/../init.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';

    if (attempt_login($email, $pass, $pdo)) {
        set_flash("Welcome back, " . current_user()['name'], "success");

        // Agar admin hai to admin panel redirect
        if (current_user()['is_admin']) {
            redirect("/admin/index.php");
        } else {
            redirect("/public/index.php");
        }
    } else {
        set_flash("Invalid email or password", "error");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #2c3e50, #1abc9c);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }

        .login-container {
            background: #fff;
            width: 360px;
            padding: 30px 25px;
            border-radius: 12px;
            box-shadow: 0 6px 18px rgba(0,0,0,0.15);
            text-align: center;
        }

        h1 {
            margin: 0 0 20px;
            color: #2c3e50;
        }

        .flash {
            margin-bottom: 20px;
            padding: 12px;
            border-radius: 6px;
            font-size: 14px;
            text-align: center;
        }

        .flash.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .flash.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            text-align: left;
            font-size: 14px;
            font-weight: bold;
            color: #2c3e50;
        }

        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccd1d9;
            border-radius: 6px;
            font-size: 14px;
        }

        input:focus {
            border-color: #1abc9c;
            outline: none;
        }

        button {
            padding: 12px;
            background: #1abc9c;
            border: none;
            border-radius: 6px;
            color: #fff;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s;
            font-size: 15px;
        }

        button:hover {
            background: #16a085;
        }

        p {
            margin-top: 20px;
            font-size: 14px;
        }

        p a {
            color: #1abc9c;
            text-decoration: none;
            font-weight: bold;
        }

        p a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>Login</h1>
        <?php if ($flash = get_flash()): ?>
            <div class="flash <?= htmlspecialchars($flash['type']) ?>">
                <?= htmlspecialchars($flash['msg']) ?>
            </div>
        <?php endif; ?>

        <form method="post">
            <label>Email:
                <input type="email" name="email" required>
            </label>
            <label>Password:
                <input type="password" name="password" required>
            </label>
            <button type="submit">Login</button>
        </form>

        <p>Don’t have an account? <a href="register.php">Register</a></p>
    </div>

    <script src="assets/js/app.js"></script>
</body>
</html>
