<?php
require_once __DIR__ . '/../init.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $pass1 = $_POST['password'] ?? '';
    $pass2 = $_POST['password2'] ?? '';

    if ($name && $email && $pass1 && $pass1 === $pass2) {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            set_flash("Email already registered.", "error");
        } else {
            $hash = password_hash($pass1, PASSWORD_DEFAULT);
            $pdo->prepare("INSERT INTO users (name,email,password_hash) VALUES (?,?,?)")
                ->execute([$name,$email,$hash]);

            set_flash("Account created! Please login.", "success");
            redirect("/public/login.php");
        }
    } else {
        set_flash("Please fill all fields correctly.", "error");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f6f9;
            color: #333;
        }

        h1 {
            text-align: center;
            background: #2c3e50;
            color: #fff;
            padding: 20px 0;
            margin: 0 0 20px 0;
        }

        .container {
            max-width: 450px;
            margin: 40px auto;
            padding: 30px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .flash {
            margin-bottom: 20px;
            padding: 12px;
            border-radius: 6px;
            font-size: 14px;
        }

        .flash.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .flash.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-weight: bold;
            font-size: 14px;
            text-align: left;
        }

        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccd1d9;
            border-radius: 6px;
            font-size: 15px;
        }

        button {
            padding: 12px;
            background: #1abc9c;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s;
        }

        button:hover {
            background: #16a085;
        }

        p {
            margin-top: 20px;
            text-align: center;
            font-size: 14px;
        }

        p a {
            color: #1abc9c;
            text-decoration: none;
            font-weight: bold;
        }

        p a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h1>Register</h1>
    <div class="container">
        <?php if ($flash = get_flash()): ?>
            <div class="flash <?= htmlspecialchars($flash['type']) ?>">
                <?= htmlspecialchars($flash['msg']) ?>
            </div>
        <?php endif; ?>

        <form method="post">
            <label>Name:
                <input type="text" name="name" required>
            </label>
            <label>Email:
                <input type="email" name="email" required>
            </label>
            <label>Password:
                <input type="password" name="password" required>
            </label>
            <label>Confirm Password:
                <input type="password" name="password2" required>
            </label>
            <button type="submit">Register</button>
        </form>

        <p>Already have an account? <a href="login.php">Login here</a></p>
    </div>

    <script src="assets/js/app.js"></script>
</body>
</html>
