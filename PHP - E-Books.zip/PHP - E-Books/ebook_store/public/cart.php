<?php
require_once __DIR__ . '/../init.php';

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// ---- Add item to cart ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_id'])) {
    $book_id = (int)$_POST['book_id'];
    $qty = max(1, (int)($_POST['qty'] ?? 1));

    if (!isset($_SESSION['cart'][$book_id])) {
        $_SESSION['cart'][$book_id] = 0;
    }
    $_SESSION['cart'][$book_id] += $qty;

    set_flash("Book added to cart!", "success");
    redirect("/public/cart.php");
}

// ---- Remove item ----
if (isset($_GET['remove'])) {
    $rid = (int)$_GET['remove'];
    unset($_SESSION['cart'][$rid]);
    set_flash("Book removed from cart", "info");
    redirect("/public/cart.php");
}

// ---- Load cart books ----
$items = [];
$total = 0;

if ($_SESSION['cart']) {
    $ids = implode(",", array_map("intval", array_keys($_SESSION['cart'])));
    $stmt = $pdo->query("SELECT * FROM books WHERE id IN ($ids)");
    $rows = $stmt->fetchAll();

    foreach ($rows as $row) {
        $qty = $_SESSION['cart'][$row['id']];
        $subtotal = $qty * $row['price'];
        $items[] = ['book' => $row, 'qty' => $qty, 'subtotal' => $subtotal];
        $total += $subtotal;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cart - E-Book Store</title>
    <style>
        /* ===== Scoped CSS for cart.php ===== */
        .cart-page * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .cart-page body {
            background: #f5f7fa;
            color: #333;
            line-height: 1.6;
        }

        .cart-page a {
            text-decoration: none;
            color: #007bff;
            transition: color 0.3s ease;
        }

        .cart-page a:hover {
            color: #0056b3;
        }

        /* Header */
        .cart-page header {
            background: linear-gradient(90deg, #4b6cb7, #182848);
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .cart-page header h1 {
            font-size: 2rem;
            letter-spacing: 1px;
            animation: fadeInDown 1s ease;
        }

        .cart-page header nav a {
            margin-left: 20px;
            font-weight: 500;
        }

        /* Main Section */
        .cart-page main {
            padding: 40px;
        }

        .cart-page h2 {
            margin-bottom: 20px;
            color: #182848;
            border-bottom: 2px solid #007bff;
            display: inline-block;
            padding-bottom: 5px;
        }

        /* Flash Messages */
        .cart-page .flash {
            padding: 15px 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            animation: fadeIn 0.8s ease;
        }
        .cart-page .flash.success { background: #d4edda; color: #155724; }
        .cart-page .flash.error { background: #f8d7da; color: #721c24; }

        /* Cart Table */
        .cart-page table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }

        .cart-page table th, .cart-page table td {
            padding: 15px 20px;
            text-align: left;
        }

        .cart-page table th {
            background: #007bff;
            color: white;
            font-weight: 500;
        }

        .cart-page table tr:not(:last-child) {
            border-bottom: 1px solid #ddd;
        }

        /* Quantity Input */
        .cart-page input[type="number"] {
            width: 60px;
            padding: 5px 10px;
            border-radius: 6px;
            border: 1px solid #ccc;
            text-align: center;
        }

        /* Buttons */
        .cart-page button {
            background: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            transition: transform 0.3s ease, background 0.3s ease;
        }

        .cart-page button:hover {
            background: #0056b3;
            transform: scale(1.05);
        }

        /* Total Section */
        .cart-page .total {
            text-align: right;
            margin-top: 20px;
            font-size: 1.2rem;
            font-weight: bold;
        }

        /* Empty Cart */
        .cart-page .empty-cart {
            text-align: center;
            padding: 50px 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }

        /* Footer */
        .cart-page footer {
            background: #182848;
            color: white;
            text-align: center;
            padding: 20px 0;
            margin-top: 40px;
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px);}
            to { opacity: 1; transform: translateY(0);}
        }

        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-20px);}
            to { opacity: 1; transform: translateY(0);}
        }
    </style>
</head>
<body>
<div class="cart-page">
    <!-- Header -->
    <header>
        <h1>Cart</h1>
        <nav>
            <a href="index.php">Home</a>
            <a href="cart.php">Cart</a>
            <a href="competition.php">Competitions</a>
            <?php if (current_user()): ?>
                <a href="downloads.php">My Downloads</a>
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
            <?php endif; ?>
        </nav>
    </header>

    <!-- Main -->
    <main>
        <?php if ($flash = get_flash()): ?>
            <div class="flash <?= htmlspecialchars($flash['type']) ?>">
                <?= htmlspecialchars($flash['msg']) ?>
            </div>
        <?php endif; ?>

        <h2>Your Cart</h2>

        <?php if (!empty($cart_items)): ?>
            <form action="cart.php" method="post">
                <table>
                    <thead>
                        <tr>
                            <th>Book</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Subtotal</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $total = 0; ?>
                        <?php foreach ($cart_items as $item): ?>
                            <?php $subtotal = $item['price'] * $item['qty']; ?>
                            <?php $total += $subtotal; ?>
                            <tr>
                                <td><?= htmlspecialchars($item['title']) ?></td>
                                <td>Rs <?= number_format($item['price']) ?></td>
                                <td>
                                    <input type="number" name="qty[<?= $item['id'] ?>]" value="<?= $item['qty'] ?>" min="1">
                                </td>
                                <td>Rs <?= number_format($subtotal) ?></td>
                                <td>
                                    <button type="submit" name="remove" value="<?= $item['id'] ?>">Remove</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="total">
                    Total: Rs <?= number_format($total) ?>
                </div>
                <br>
                <button type="submit" name="update">Update Cart</button>
                <button type="submit" name="checkout">Proceed to Checkout</button>
            </form>
        <?php else: ?>
            <div class="empty-cart">
                <p>Your cart is empty!</p>
                <a href="index.php"><button>Browse Books</button></a>
            </div>
        <?php endif; ?>
    </main>

    <!-- Footer -->
    <footer>
        <p>&copy; <?= date('Y') ?> E-Book Store</p>
    </footer>
</div>
</body>
</html>
