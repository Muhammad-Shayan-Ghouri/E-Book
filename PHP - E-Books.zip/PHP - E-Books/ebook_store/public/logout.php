<?php
require_once __DIR__ . '/../init.php';

do_logout();
set_flash("You have been logged out.", "info");
redirect("/public/index.php");
