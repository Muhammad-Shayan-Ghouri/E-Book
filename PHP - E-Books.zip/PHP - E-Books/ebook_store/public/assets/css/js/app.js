// Simple animation + interactivity
document.addEventListener("DOMContentLoaded", () => {
    // Flash message auto hide
    const flash = document.querySelector(".flash");
    if (flash) {
        setTimeout(() => {
            flash.style.transition = "opacity 0.5s";
            flash.style.opacity = "0";
        }, 4000);
    }

    // Button hover ripple effect
    document.querySelectorAll("button").forEach(btn => {
        btn.addEventListener("click", function(e) {
            let circle = document.createElement("span");
            circle.classList.add("ripple");
            this.appendChild(circle);

            let d = Math.max(this.clientWidth, this.clientHeight);
            circle.style.width = circle.style.height = d + "px";
            circle.style.left = e.clientX - this.offsetLeft - d/2 + "px";
            circle.style.top = e.clientY - this.offsetTop - d/2 + "px";

            setTimeout(() => circle.remove(), 600);
        });
    });
});
