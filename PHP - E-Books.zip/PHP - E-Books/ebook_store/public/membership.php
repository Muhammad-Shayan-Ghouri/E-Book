<?php
require_once __DIR__ . '/../init.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $months = (int)($_POST['months'] ?? 1);
    if ($months < 1) $months = 1;

    $until = date('Y-m-d H:i:s', strtotime("+$months month"));

    $pdo->prepare("UPDATE users SET membership_until = ? WHERE id = ?")
        ->execute([$until, current_user()['id']]);

    // update session
    $_SESSION['user']['membership_until'] = $until;

    set_flash("Membership activated till $until", "success");
    redirect("/public/membership.php");
}

$user = current_user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Membership</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f6f9;
            color: #333;
        }

        h1 {
            text-align: center;
            background: #2c3e50;
            color: #fff;
            padding: 20px 0;
            margin: 0;
        }

        nav {
            background: #34495e;
            display: flex;
            justify-content: center;
            gap: 20px;
            padding: 12px 0;
        }

        nav a {
            color: #ecf0f1;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s;
        }

        nav a:hover {
            color: #1abc9c;
        }

        .container {
            max-width: 600px;
            margin: 30px auto;
            padding: 25px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            text-align: center;
        }

        .flash {
            margin-bottom: 20px;
            padding: 12px;
            border-radius: 6px;
            font-size: 14px;
        }

        .flash.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .flash.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        p {
            font-size: 16px;
            margin: 20px 0;
        }

        form {
            margin-top: 20px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 10px;
            text-align: left;
        }

        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccd1d9;
            border-radius: 6px;
            font-size: 15px;
            margin-bottom: 20px;
        }

        button {
            display: inline-block;
            padding: 12px 20px;
            background: #1abc9c;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s;
        }

        button:hover {
            background: #16a085;
        }
    </style>
</head>
<body>
    <h1>Membership</h1>
    <nav>
        <a href="index.php">Home</a>
        <a href="cart.php">Cart</a>
        <a href="competition.php">Competitions</a>
        <a href="downloads.php">My Downloads</a>
    </nav>

    <div class="container">
        <?php if ($flash = get_flash()): ?>
            <div class="flash <?= htmlspecialchars($flash['type']) ?>">
                <?= htmlspecialchars($flash['msg']) ?>
            </div>
        <?php endif; ?>

        <?php if ($user['membership_until'] && strtotime($user['membership_until']) > time()): ?>
            <p><strong>Your membership is active till:</strong><br> <?= $user['membership_until'] ?></p>
        <?php else: ?>
            <p>You don’t have an active membership.</p>
            <form method="post">
                <label for="months">Choose your plan:</label>
                <select name="months" id="months">
                    <option value="1">1 month - Rs 499</option>
                    <option value="3">3 months - Rs 1299</option>
                    <option value="6">6 months - Rs 2499</option>
                </select>
                <button type="submit">Buy Membership</button>
            </form>
        <?php endif; ?>
    </div>

    <script src="assets/js/app.js"></script>
</body>
</html>
