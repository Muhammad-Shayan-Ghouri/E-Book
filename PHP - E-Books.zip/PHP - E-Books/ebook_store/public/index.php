<?php
require_once __DIR__ . '/../init.php';

// Books load
$books = $pdo->query("SELECT * FROM books WHERE is_active = 1 ORDER BY created_at DESC")->fetchAll();

// Active competitions
$now = date('Y-m-d H:i:s');
$competitions = $pdo->prepare("SELECT * FROM competitions WHERE start_datetime <= ? AND end_datetime >= ?");
$competitions->execute([$now, $now]);
$competitions = $competitions->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>E-Book Store</title>
    <style>
        /* ===== Scoped CSS for index.php ===== */
        .index-page * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .index-page body {
            background: #f5f7fa;
            color: #333;
            line-height: 1.6;
        }

        .index-page a {
            text-decoration: none;
            color: #007bff;
            transition: color 0.3s ease;
        }

        .index-page a:hover {
            color: #0056b3;
        }

        /* Header */
        .index-page header {
            background: linear-gradient(90deg, #4b6cb7, #182848);
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .index-page header h1 {
            font-size: 2rem;
            letter-spacing: 1px;
            animation: fadeInDown 1s ease;
        }

        .index-page header nav a {
            margin-left: 20px;
            font-weight: 500;
        }

        /* Main Section */
        .index-page main {
            padding: 40px;
        }

        .index-page h2 {
            margin-bottom: 20px;
            color: #182848;
            border-bottom: 2px solid #007bff;
            display: inline-block;
            padding-bottom: 5px;
        }

        /* Flash Messages */
        .index-page .flash {
            padding: 15px 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            animation: fadeIn 0.8s ease;
        }
        .index-page .flash.success { background: #d4edda; color: #155724; }
        .index-page .flash.error { background: #f8d7da; color: #721c24; }

        /* Grid Layout */
        .index-page .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        /* Book Card (Static) */
        .index-page .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 20px;
            min-height: 220px;
        }

        .index-page .card:hover {
            transform: translateY(-8px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        }

        .index-page .card h3 {
            margin-bottom: 10px;
            color: #182848;
        }

        .index-page .card p {
            margin-bottom: 10px;
        }

        /* Add to Cart Button */
        .index-page .card button {
            background: #007bff;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            transition: transform 0.3s ease, background 0.3s ease;
            margin-top: auto;
        }

        .index-page .card button:hover {
            background: #0056b3;
            transform: scale(1.05);
        }

        /* Competitions */
        .index-page ul {
            list-style: none;
            padding-left: 0;
        }

        .index-page ul li {
            background: white;
            margin-bottom: 10px;
            padding: 15px 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
            transition: transform 0.3s ease;
        }

        .index-page ul li:hover {
            transform: translateX(10px);
        }

        /* Footer */
        .index-page footer {
            background: #182848;
            color: white;
            text-align: center;
            padding: 20px 0;
            margin-top: 40px;
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px);}
            to { opacity: 1; transform: translateY(0);}
        }

        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-20px);}
            to { opacity: 1; transform: translateY(0);}
        }
    </style>
</head>
<body>
<div class="index-page">
    <!-- Header -->
    <header>
        <h1>E-Book Store</h1>
        <nav>
            <a href="index.php">Home</a>
            <a href="cart.php">Cart</a>
            <a href="competition.php">Competitions</a>
            <?php if (current_user()): ?>
                <a href="downloads.php">My Downloads</a>
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
            <?php endif; ?>
        </nav>
    </header>

    <!-- Main -->
    <main>
        <?php if ($flash = get_flash()): ?>
            <div class="flash <?= htmlspecialchars($flash['type']) ?>">
                <?= htmlspecialchars($flash['msg']) ?>
            </div>
        <?php endif; ?>

        <!-- Available Books -->
        <section>
            <h2>Available Books</h2>
            <div class="grid">
                <?php foreach ($books as $b): ?>
                    <div class="card">
                        <h3><?= htmlspecialchars($b['title']) ?></h3>
                        <p><em>by <?= htmlspecialchars($b['author']) ?></em></p>
                        <p><?= nl2br(htmlspecialchars($b['description'])) ?></p>
                        <p><strong>Rs <?= number_format($b['price']) ?></strong> (<?= $b['format'] ?>)</p>
                        <form action="cart.php" method="post">
                            <input type="hidden" name="book_id" value="<?= $b['id'] ?>">
                            <input type="hidden" name="qty" value="1">
                            <button type="submit">Add to Cart</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

        <!-- Competitions -->
        <section>
            <h2>Ongoing Competitions</h2>
            <?php if ($competitions): ?>
                <ul>
                    <?php foreach ($competitions as $c): ?>
                        <li>
                            <strong><?= htmlspecialchars($c['name']) ?></strong>
                            (till <?= date('d M Y H:i', strtotime($c['end_datetime'])) ?>) –
                            <a href="competition.php?id=<?= $c['id'] ?>">View / Join</a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>No competitions active right now.</p>
            <?php endif; ?>
        </section>
    </main>

    <!-- Footer -->
    <footer>
        <p>&copy; <?= date('Y') ?> E-Book Store</p>
    </footer>
</div>
</body>
</html>
