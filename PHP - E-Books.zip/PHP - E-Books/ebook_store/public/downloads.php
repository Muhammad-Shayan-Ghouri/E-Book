<?php
require_once __DIR__ . '/../init.php';
require_login();

// User ke orders fetch karo jisme PDF books hain
$stmt = $pdo->prepare("
    SELECT b.title, b.file_path, o.status 
    FROM orders o
    JOIN order_items oi ON o.id = oi.order_id
    JOIN books b ON oi.book_id = b.id
    WHERE o.user_id = ? AND b.format = 'pdf' AND b.file_path IS NOT NULL
");
$stmt->execute([current_user()['id']]);
$downloads = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Downloads</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f6f9;
            color: #333;
        }

        h1 {
            text-align: center;
            background: #2c3e50;
            color: #fff;
            padding: 20px 0;
            margin: 0;
        }

        nav {
            background: #34495e;
            display: flex;
            justify-content: center;
            gap: 20px;
            padding: 12px 0;
        }

        nav a {
            color: #ecf0f1;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s;
        }

        nav a:hover {
            color: #1abc9c;
        }

        main {
            max-width: 900px;
            margin: 30px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        li {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 12px 0;
            padding: 14px 18px;
            background: #f8f9fa;
            border-radius: 6px;
            transition: background 0.2s, transform 0.2s;
        }

        li:hover {
            background: #eef2f3;
            transform: translateX(5px);
        }

        a.download-btn {
            padding: 8px 16px;
            background: #1abc9c;
            color: white;
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
            transition: background 0.3s;
        }

        a.download-btn:hover {
            background: #16a085;
        }

        p {
            text-align: center;
            font-size: 16px;
            color: #555;
        }
    </style>
</head>
<body>
    <h1>My Downloads</h1>
    <nav>
        <a href="index.php">Home</a>
        <a href="cart.php">Cart</a>
        <a href="competition.php">Competitions</a>
        <a href="logout.php">Logout</a>
    </nav>

    <main>
        <?php if ($downloads): ?>
            <ul>
            <?php foreach ($downloads as $d): ?>
                <li>
                    <span><?= htmlspecialchars($d['title']) ?></span>
                    <?php if ($d['status'] === 'paid' || $d['status'] === 'pending' || $d['status'] === 'shipped'): ?>
                        <a class="download-btn" href="../<?= htmlspecialchars($d['file_path']) ?>" download>Download PDF</a>
                    <?php else: ?>
                        <span style="color:#e74c3c;">(Not available)</span>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>No downloads available yet.</p>
        <?php endif; ?>
    </main>

    <script src="assets/js/app.js"></script>
</body>
</html>
